#include <iostream>
#include "sculptor.h"
#include <fstream>
#include <string>

using namespace std;

int main()
{
    Sculptor s(20,20,20);
    //FiguraGeometrica *f;
    //PutBox *pbx,bx;
    //f = new PutBox(5,5,1,4,3,10);
    //f->draw(s);
    s.setColor(0,0,1,1);
    s.putVoxel(5,5,5);
    s.setColor(0,0,1,1);
    s.putVoxel(1,2,2);
    s.cutVoxel(0,0,0);

    s.writeOFF("/home/rafaella/Documentos/ProjetoPARTE02/arquivo.OFF");
    s.writeVECT("/home/rafaella/Documentos/ProjetoPARTE02/arquivo.VECT");


    return 0;
}
