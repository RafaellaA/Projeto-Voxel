#ifndef PUTELLIPSOID_H
#define PUTELLIPSOID_H
#include "figurageometrica.h"

class PutEllipsoid:public FiguraGeometrica
{
private:
    int nx,ny,nz;
    int xcenter,ycenter,zcenter,rx,ry,rz;
    float r,g,b,alpha;
public:
    PutEllipsoid(int _nx,int _ny, int _nz,int icenter,int jcenter, int kcenter, int _rx,int _ry, int _rz);
    void draw(Sculptor &s);
};

#endif // PUTELLIPSOID_H

