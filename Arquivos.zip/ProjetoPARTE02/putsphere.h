#ifndef PUTSPHERE_H
#define PUTSPHERE_H
#include "figurageometrica.h"

class PutSphere:public FiguraGeometrica
{
private:
    int nx,ny,nz;
    float r,g,b,alpha;
    int xcenter,ycenter,zcenter,radius;
public:
    PutSphere(int _nx,int _ny,int _nz,int icenter,int jcenter,int kcenter,int r);
    void draw(Sculptor &s);
};

#endif // PUTSPHERE_H

