#ifndef CUTVOXEL_H
#define CUTVOXEL_H
#include "figurageometrica.h"

class CutVoxel:public FiguraGeometrica
{
private:
    int x,y,z;
    float r,g,b,alpha;
public:
    CutVoxel(int mx,int my,int mz,float mr,float mg,float mb,float ma);
    void draw(Sculptor &s);
};

#endif // CUTVOXEL_H
