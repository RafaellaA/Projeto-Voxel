#include "cutvoxel.h"

CutVoxel::CutVoxel(int mx, int my, int mz, float mr, float mg, float mb, float ma)
{
    x=mx; y=my; z=mz;
    r=mr; g=mg; b=mg; alpha=ma;
}

void CutVoxel::draw(Sculptor &s)
{
    s.cutVoxel(x,y,z);
}
