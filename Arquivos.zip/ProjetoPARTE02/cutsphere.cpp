#include "cutsphere.h"

CutSphere::CutSphere(int _nx,int _ny,int _nz,int _xcenter, int _ycenter, int _zcenter, int _radius)
{
    xcenter = _xcenter;
        ycenter = _ycenter;
        zcenter = _zcenter;
        radius = _radius;
}

void CutSphere::draw(Sculptor &s)
{
    for(int i = 0; i<nx; i++){
            for(int j = 0; j<ny; j++){
                for(int k = 0; k<nz; k++){
                    if( ((i - xcenter)*(i - xcenter) + (j - ycenter)*(j - ycenter) + (k - zcenter)*(k - zcenter)) <= radius*radius ){
                        s.cutVoxel(i, j, k);
                    }
                }
            }
        }


}
