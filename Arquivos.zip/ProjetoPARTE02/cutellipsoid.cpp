#include "cutellipsoid.h"

CutEllipsoid::CutEllipsoid(int _nx,int _ny,int _nz,int _xcenter, int _ycenter, int _zcenter, int _rx, int _ry, int _rz)
{
    nx= _nx; ny = _ny;nz = _nz;
    xcenter = _xcenter; ycenter = _ycenter; zcenter = _zcenter;
    rx = _rx; ry = _ry; rz = _rz;
}

void CutEllipsoid::draw(Sculptor &s)
{
    for(int i = 0; i<nx; i++){
            for(int j = 0; j<ny; j++){
                for(int k = 0; k<nz; k++){
                    if( (((i - xcenter)*(i - xcenter))/(float)(rx*rx) + ((j - ycenter)*(j - ycenter))/(float)(ry*ry) + ((k - zcenter)*(k - zcenter))/(float)(rz*rz)) <= 1 ){
                        s.cutVoxel(i, j, k);
                    }
                }
            }
        }
}
